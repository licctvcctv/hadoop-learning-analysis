#!/bin/bash
# ============================================
# 学习行为分析系统 - 虚拟机一键部署脚本
# 适用于 CentOS 7 系统
# ============================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step() { echo -e "${BLUE}[STEP]${NC} $1"; }

# 获取本机 IP
get_local_ip() {
    hostname -I | awk '{print $1}'
}

LOCAL_IP=$(get_local_ip)
PROJECT_DIR=$(cd "$(dirname "$0")" && pwd)

echo "============================================"
echo "  学习行为分析系统 - 一键部署"
echo "============================================"
echo "  项目目录: $PROJECT_DIR"
echo "  本机 IP:  $LOCAL_IP"
echo "============================================"
echo ""

# ==================== 1. 停止 Docker (如果运行) ====================
log_step "1/7 停止 Docker 服务..."
if command -v docker &> /dev/null; then
    docker stop $(docker ps -aq) 2>/dev/null || true
    systemctl stop docker 2>/dev/null || service docker stop 2>/dev/null || true
    log_info "Docker 已停止"
else
    log_info "Docker 未安装，跳过"
fi

# ==================== 2. 安装 Java ====================
log_step "2/7 检查 Java 环境..."
if ! command -v java &> /dev/null; then
    log_info "安装 OpenJDK 8..."
    yum install -y java-1.8.0-openjdk java-1.8.0-openjdk-devel -q
fi
log_info "Java 版本: $(java -version 2>&1 | head -1)"

# ==================== 3. 安装 Hadoop ====================
log_step "3/7 检查 Hadoop..."
HADOOP_VERSION="3.3.6"
HADOOP_HOME="/opt/hadoop"

if [ ! -d "$HADOOP_HOME" ]; then
    log_info "下载 Hadoop $HADOOP_VERSION..."
    cd /opt
    
    # 尝试多个镜像源
    MIRRORS=(
        "https://repo.huaweicloud.com/apache/hadoop/common/hadoop-${HADOOP_VERSION}/hadoop-${HADOOP_VERSION}.tar.gz"
        "https://mirrors.aliyun.com/apache/hadoop/common/hadoop-${HADOOP_VERSION}/hadoop-${HADOOP_VERSION}.tar.gz"
        "https://archive.apache.org/dist/hadoop/common/hadoop-${HADOOP_VERSION}/hadoop-${HADOOP_VERSION}.tar.gz"
    )
    
    for mirror in "${MIRRORS[@]}"; do
        log_info "尝试下载: $mirror"
        if wget -q "$mirror" -O hadoop.tar.gz; then
            break
        fi
    done
    
    if [ -f hadoop.tar.gz ]; then
        log_info "解压 Hadoop..."
        tar -xzf hadoop.tar.gz
        mv hadoop-${HADOOP_VERSION} hadoop
        rm -f hadoop.tar.gz
        log_info "Hadoop 安装完成"
    else
        log_error "Hadoop 下载失败"
        exit 1
    fi
else
    log_info "Hadoop 已安装"
fi

# ==================== 4. 安装 Spark ====================
log_step "4/7 检查 Spark..."
SPARK_VERSION="3.5.0"
SPARK_HOME="/opt/spark"

if [ ! -d "$SPARK_HOME" ]; then
    log_info "下载 Spark $SPARK_VERSION..."
    cd /opt
    
    MIRRORS=(
        "https://repo.huaweicloud.com/apache/spark/spark-${SPARK_VERSION}/spark-${SPARK_VERSION}-bin-hadoop3.tgz"
        "https://mirrors.aliyun.com/apache/spark/spark-${SPARK_VERSION}/spark-${SPARK_VERSION}-bin-hadoop3.tgz"
        "https://archive.apache.org/dist/spark/spark-${SPARK_VERSION}/spark-${SPARK_VERSION}-bin-hadoop3.tgz"
    )
    
    for mirror in "${MIRRORS[@]}"; do
        log_info "尝试下载: $mirror"
        if wget -q "$mirror" -O spark.tgz; then
            break
        fi
    done
    
    if [ -f spark.tgz ]; then
        log_info "解压 Spark..."
        tar -xzf spark.tgz
        mv spark-${SPARK_VERSION}-bin-hadoop3 spark
        rm -f spark.tgz
        log_info "Spark 安装完成"
    else
        log_error "Spark 下载失败"
        exit 1
    fi
else
    log_info "Spark 已安装"
fi

# ==================== 5. 配置环境 ====================
log_step "5/7 配置环境变量..."

# 环境变量
cat > /etc/profile.d/hadoop.sh << 'EOF'
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk
export HADOOP_HOME=/opt/hadoop
export SPARK_HOME=/opt/spark
export PATH=$PATH:$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$SPARK_HOME/bin
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
EOF
source /etc/profile.d/hadoop.sh

# Hadoop 环境配置
cat > $HADOOP_HOME/etc/hadoop/hadoop-env.sh << EOF
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk
export HDFS_NAMENODE_USER=root
export HDFS_DATANODE_USER=root
export HDFS_SECONDARYNAMENODE_USER=root
export YARN_RESOURCEMANAGER_USER=root
export YARN_NODEMANAGER_USER=root
EOF

# core-site.xml
cat > $HADOOP_HOME/etc/hadoop/core-site.xml << EOF
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <property>
        <name>fs.defaultFS</name>
        <value>hdfs://localhost:9000</value>
    </property>
    <property>
        <name>hadoop.tmp.dir</name>
        <value>/opt/hadoop/tmp</value>
    </property>
</configuration>
EOF

# hdfs-site.xml
cat > $HADOOP_HOME/etc/hadoop/hdfs-site.xml << EOF
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>/opt/hadoop/data/namenode</value>
    </property>
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>/opt/hadoop/data/datanode</value>
    </property>
    <property>
        <name>dfs.webhdfs.enabled</name>
        <value>true</value>
    </property>
</configuration>
EOF

# 创建目录
mkdir -p $HADOOP_HOME/tmp $HADOOP_HOME/data/namenode $HADOOP_HOME/data/datanode

# SSH 免密登录
if [ ! -f ~/.ssh/id_rsa ]; then
    ssh-keygen -t rsa -P "" -f ~/.ssh/id_rsa -q
fi
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys 2>/dev/null || true
chmod 600 ~/.ssh/authorized_keys

log_info "环境配置完成"

# ==================== 6. 启动 Hadoop ====================
log_step "6/7 启动 Hadoop..."

# 检查是否需要格式化
if [ ! -d "$HADOOP_HOME/data/namenode/current" ]; then
    log_info "格式化 HDFS..."
    hdfs namenode -format -force 2>/dev/null
fi

# 停止旧进程
stop-dfs.sh 2>/dev/null || true
sleep 2

# 启动 HDFS
log_info "启动 HDFS..."
start-dfs.sh

sleep 5

# 验证
if jps | grep -q "NameNode"; then
    log_info "HDFS 启动成功"
else
    log_error "HDFS 启动失败"
    exit 1
fi

# 创建 HDFS 目录
hdfs dfs -mkdir -p /user/learning_behavior/raw 2>/dev/null || true
hdfs dfs -mkdir -p /user/learning_behavior/results 2>/dev/null || true
hdfs dfs -chmod -R 777 /user/learning_behavior 2>/dev/null || true

# ==================== 7. 启动 Web 服务 ====================
log_step "7/7 启动 Web 服务..."

# 安装 Python 依赖
pip3 install flask requests -q 2>/dev/null || pip install flask requests -q 2>/dev/null

# 停止旧进程
pkill -f "python.*app.py" 2>/dev/null || true
sleep 2

# 创建日志目录
mkdir -p $PROJECT_DIR/logs/web

# 启动 Web 服务
cd $PROJECT_DIR
export HDFS_HOST=localhost
export HDFS_PORT=9870
nohup python3 src/web/app.py > logs/web/app.log 2>&1 &

sleep 3

if pgrep -f "python.*app.py" > /dev/null; then
    log_info "Web 服务启动成功"
else
    log_error "Web 服务启动失败"
    cat logs/web/app.log
    exit 1
fi

# ==================== 完成 ====================
echo ""
echo "============================================"
echo -e "  ${GREEN}部署完成!${NC}"
echo "============================================"
echo ""
echo "  运行进程:"
jps | grep -v Jps | while read line; do echo "    - $line"; done
echo "    - Web App (Flask)"
echo ""
echo "  访问地址:"
echo "    - Web 可视化:  http://${LOCAL_IP}:5000"
echo "    - HDFS Web UI: http://${LOCAL_IP}:9870"
echo ""
echo "  默认登录: admin / admin123"
echo ""
echo "  常用命令:"
echo "    - 查看日志: tail -f $PROJECT_DIR/logs/web/app.log"
echo "    - 停止服务: $PROJECT_DIR/stop.sh"
echo "    - 查看HDFS: hdfs dfs -ls /user/learning_behavior/raw"
echo "============================================"
