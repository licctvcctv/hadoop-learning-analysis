# ============================================
# Spark分析模块
# 基于Hadoop的大学生线上课程学习行为数据存储与分析系统
# ============================================

from .logger import setup_spark_logger

__all__ = ['setup_spark_logger']
__version__ = '1.0.0'
